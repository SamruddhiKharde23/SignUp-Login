const firebaseConfig = {
  apiKey: "AIzaSyCdg0OEB9PGb8pR1o0OxRLtNzP0nBaBhxY",
  authDomain: "signup-224dd.firebaseapp.com",
  databaseURL: "https://signup-224dd-default-rtdb.firebaseio.com",
  projectId: "signup-224dd",
  storageBucket: "signup-224dd.appspot.com",
  messagingSenderId: "387487791166",
  appId: "1:387487791166:web:f62c7244e135e08f4e796f"
};
  //intialize firebase 
  firebase.initializeApp(firebaseConfig);

  //create reference database
  var SignUpDB = firebase.database().ref('SignUp');

  document.getElementById('SignUp').addEventListener('submit',loginform);

  function loginform(e){
    e.preventDefault();

    var uname = getInputVal('uname');
    var upass = getInputVal('pass');
    console.log(uname,upass);
    saveDetails(uname,upass);

  }
  
  function getInputVal(id){
    return document.getElementById(id).value;
  }

  function saveDetails(uname,upass) {
    var newSignUp = SignUpDB.push();
    newSignUp.set({
         name: uname,
         pass: upass,
    })

  }

  

 